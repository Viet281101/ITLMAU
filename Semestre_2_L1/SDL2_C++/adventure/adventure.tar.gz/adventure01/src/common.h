/*
 * Copyright (C) 2021-2022 Parallel Realities. All rights reserved.
 */

#include <math.h>
#include <SDL2/SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "defs.h"
#include "structs.h"
