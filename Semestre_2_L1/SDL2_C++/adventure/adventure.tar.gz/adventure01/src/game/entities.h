/*
 * Copyright (C) 2021-2022 Parallel Realities. All rights reserved.
 */

void	drawEntities(void);
Entity *spawnEntity(void);
void	initEntities(void);
