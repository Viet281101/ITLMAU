/*
 * Copyright (C) 2021-2022 Parallel Realities. All rights reserved.
 */

char		 *readFile(char *filename);
unsigned long hashcode(const char *str);
