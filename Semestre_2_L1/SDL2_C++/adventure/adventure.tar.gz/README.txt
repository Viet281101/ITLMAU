Thank you for purchasing this tutorial. We hope you find it useful.

You can find the entire series at:

https://www.parallelrealities.co.uk/tutorials

If you didn't purchase this tutorial, then please do so from itch.io:

https://parallelrealities.itch.io

This will encourage us to make more tutorials in future.

Many thanks!
