/*
 * Copyright (C) 2021-2022 Parallel Realities. All rights reserved.
 */

int	 addToInventory(Entity *e);
void initInventoryView(void);
void initInventory(void);
