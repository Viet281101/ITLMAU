/*
 * Copyright (C) 2021-2022 Parallel Realities. All rights reserved.
 */

void initGoldCoins(int x, int y);
void initGoldCoin(int x, int y);
