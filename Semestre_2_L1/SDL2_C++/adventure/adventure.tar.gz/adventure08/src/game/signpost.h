/*
 * Copyright (C) 2021-2022 Parallel Realities. All rights reserved.
 */

void initSignPost(int x, int y, char *message);
