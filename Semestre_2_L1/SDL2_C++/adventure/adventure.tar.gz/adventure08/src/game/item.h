/*
 * Copyright (C) 2021-2022 Parallel Realities. All rights reserved.
 */

Entity *initItem(char *name, int x, int y, char *texture);
