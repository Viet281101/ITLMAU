/*
 * Copyright (C) 2021-2022 Parallel Realities. All rights reserved.
 */

void initBat(Entity *e);
