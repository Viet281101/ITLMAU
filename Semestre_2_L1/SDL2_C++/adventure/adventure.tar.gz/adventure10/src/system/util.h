/*
 * Copyright (C) 2021-2022 Parallel Realities. All rights reserved.
 */

char		 *readFile(char *filename);
int			  getDistance(int x1, int y1, int x2, int y2);
unsigned long hashcode(const char *str);
