/*
 * Copyright (C) 2021-2022 Parallel Realities. All rights reserved.
 */

void addMessageBox(char *speaker, char *message, int r, int g, int b);
void drawMessageBox(void);
void doMessageBox(void);
void initMessageBox(void);
