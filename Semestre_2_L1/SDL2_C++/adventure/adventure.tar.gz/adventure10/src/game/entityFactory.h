/*
 * Copyright (C) 2021-2022 Parallel Realities. All rights reserved.
 */

void initEntity(cJSON *root);
void initEntityFactory(void);
